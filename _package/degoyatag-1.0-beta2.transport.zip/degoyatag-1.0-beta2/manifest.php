<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4d80ff91ac1b46e1c8817b0b5515626f',
      'native_key' => 'degoyaTag',
      'filename' => 'modNamespace/41ebbdd14e56b6f4b22c91118d03bc9b.vehicle',
      'namespace' => 'degoyaTag',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '171c385620d2f05a8bb2edd2ebb27d05',
      'native_key' => 28,
      'filename' => 'modPlugin/a9ba1f46b1b1df4fe2126ce4a3dc8750.vehicle',
      'namespace' => 'degoyaTag',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f4d7e86d1c28ddc7575230cc3ffce812',
      'native_key' => 1,
      'filename' => 'modCategory/956ca6478294fad882d697be8d2df3c7.vehicle',
      'namespace' => 'degoyaTag',
    ),
  ),
);